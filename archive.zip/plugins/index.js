module.exports = [
  require('inert'),
  require('hapi-auth-cookie')
]
